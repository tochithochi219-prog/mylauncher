package com.example.mylauncher

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.GridLayoutManager
import com.example.mylauncher.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var drawerAdapter: AppAdapter
    private lateinit var dockAdapter: AppAdapter
    private var allApps: List<AppInfo> = emptyList()
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        // วาดใต้ status bar / nav bar แล้วเว้นขอบตาม inset
        WindowCompat.setDecorFitsSystemWindows(window, false)
        ViewCompat.setOnApplyWindowInsetsListener(b.container) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }

        drawerAdapter = AppAdapter(true, ::launch, ::showAppMenu)
        dockAdapter = AppAdapter(false, ::launch, ::showAppMenu)

        b.appList.layoutManager = GridLayoutManager(this, 4)
        b.appList.adapter = drawerAdapter
        b.dock.layoutManager = GridLayoutManager(this, 4)
        b.dock.adapter = dockAdapter

        b.search.doAfterTextChanged { filterApps(it?.toString().orEmpty()) }

        // ปัดขึ้นที่หน้าโฮมเพื่อเปิด drawer
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (vy < -1000f) { openDrawer(); return true }
                return false
            }
        })
        b.home.setOnTouchListener { _, ev -> detector.onTouchEvent(ev) }

        // กดปุ่ม Back = ปิด drawer (ถ้าอยู่หน้าโฮมไม่ทำอะไร)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (b.drawer.visibility == View.VISIBLE) closeDrawer()
            }
        })
    }

    override fun onResume() {
        super.onResume()
        loadApps() // โหลดใหม่ทุกครั้ง เผื่อมีแอปติดตั้ง/ถอนใหม่
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // กดปุ่ม Home ซ้ำ = กลับหน้าโฮม
        if (intent.hasCategory(Intent.CATEGORY_HOME)) closeDrawer()
    }

    // ---------- โหลดแอป ----------
    private fun loadApps() {
        Thread {
            val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = packageManager.queryIntentActivities(query, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    AppInfo(
                        it.loadLabel(packageManager).toString(),
                        it.activityInfo.packageName,
                        it.loadIcon(packageManager)
                    )
                }
                .distinctBy { it.packageName }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                allApps = list
                filterApps(b.search.text?.toString().orEmpty())
                refreshDock()
            }
        }.start()
    }

    private fun filterApps(q: String) {
        val text = q.trim().lowercase()
        drawerAdapter.submit(
            if (text.isEmpty()) allApps else allApps.filter { it.label.lowercase().contains(text) }
        )
    }

    // ---------- Dock ----------
    private fun dockPackages(): List<String> =
        prefs.getString("dock", "").orEmpty().split(",").filter { it.isNotBlank() }

    private fun saveDock(list: List<String>) {
        prefs.edit().putString("dock", list.joinToString(",")).apply()
        refreshDock()
    }

    private fun refreshDock() {
        val pinned = dockPackages().mapNotNull { pkg -> allApps.find { it.packageName == pkg } }
        dockAdapter.submit(pinned)
        b.dock.visibility = if (pinned.isEmpty()) View.GONE else View.VISIBLE
    }

    // ---------- เปิดแอป / เมนูกดค้าง ----------
    private fun launch(app: AppInfo) {
        packageManager.getLaunchIntentForPackage(app.packageName)?.let {
            startActivity(it)
            closeDrawer()
        }
    }

    private fun showAppMenu(app: AppInfo) {
        val pinned = app.packageName in dockPackages()
        val options = arrayOf(
            getString(if (pinned) R.string.unpin_dock else R.string.pin_dock),
            getString(R.string.app_info),
            getString(R.string.uninstall)
        )
        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> togglePin(app, pinned)
                    1 -> startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:${app.packageName}"))
                    )
                    2 -> startActivity(
                        Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}"))
                    )
                }
            }
            .show()
    }

    private fun togglePin(app: AppInfo, pinned: Boolean) {
        val cur = dockPackages().toMutableList()
        if (pinned) {
            cur.remove(app.packageName)
        } else {
            if (cur.size >= 4) {
                Toast.makeText(this, R.string.dock_full, Toast.LENGTH_SHORT).show()
                return
            }
            cur.add(app.packageName)
        }
        saveDock(cur)
    }

    // ---------- Drawer ----------
    private fun openDrawer() {
        b.drawer.visibility = View.VISIBLE
    }

    private fun closeDrawer() {
        b.drawer.visibility = View.GONE
        b.search.setText("")
        b.search.clearFocus()
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(b.root.windowToken, 0)
    }
}
