# MyLauncher
Launcher พื้นฐาน (Kotlin, View system): นาฬิกา + Dock + App drawer + ค้นหา + กดค้างเพื่อปักแอป/ข้อมูลแอป/ถอนการติดตั้ง

Build (ต้องมี JDK 17 + Android SDK, สร้าง local.properties: sdk.dir=...):
    gradle wrapper --gradle-version 8.7     # ครั้งแรกครั้งเดียว
    ./gradlew assembleDebug --no-daemon     # Windows: gradlew.bat assembleDebug --no-daemon
APK: app/build/outputs/apk/debug/app-debug.apk
