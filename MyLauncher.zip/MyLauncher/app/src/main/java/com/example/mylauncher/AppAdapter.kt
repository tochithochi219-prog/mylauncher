package com.example.mylauncher

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.mylauncher.databinding.ItemAppBinding

class AppAdapter(
    private val showLabel: Boolean,
    private val onClick: (AppInfo) -> Unit,
    private val onLongClick: (AppInfo) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var items: List<AppInfo> = emptyList()

    fun submit(list: List<AppInfo>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(val b: ItemAppBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemAppBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = items[position]
        holder.b.icon.setImageDrawable(app.icon)
        holder.b.label.text = app.label
        holder.b.label.visibility = if (showLabel) View.VISIBLE else View.GONE
        holder.b.root.setOnClickListener { onClick(app) }
        holder.b.root.setOnLongClickListener { onLongClick(app); true }
    }

    override fun getItemCount() = items.size
}
